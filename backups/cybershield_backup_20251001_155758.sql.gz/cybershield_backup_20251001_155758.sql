--
-- PostgreSQL database dump
--

\restrict iMKWlOd5aaoDxHZSjfQpKfPmjEE033hfUcaj4kbVqGJdg9vlH5WD9a2oycqiu3T

-- Dumped from database version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cve_entries; Type: TABLE; Schema: public; Owner: pabit_user
--

CREATE TABLE public.cve_entries (
    id integer NOT NULL,
    cve_id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    cvss_score numeric,
    severity text NOT NULL,
    vendor text,
    published_date text,
    updated_date text,
    tags text[] DEFAULT '{}'::text[],
    actively_exploited boolean DEFAULT false,
    edb_id text,
    "references" text
);


ALTER TABLE public.cve_entries OWNER TO pabit_user;

--
-- Name: cve_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: pabit_user
--

CREATE SEQUENCE public.cve_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cve_entries_id_seq OWNER TO pabit_user;

--
-- Name: cve_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pabit_user
--

ALTER SEQUENCE public.cve_entries_id_seq OWNED BY public.cve_entries.id;


--
-- Name: exploits; Type: TABLE; Schema: public; Owner: pabit_user
--

CREATE TABLE public.exploits (
    id integer NOT NULL,
    cve_id text NOT NULL,
    exploit_id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    exploit_type text NOT NULL,
    platform text NOT NULL,
    verified boolean DEFAULT false,
    date_published text NOT NULL,
    author text NOT NULL,
    source_url text NOT NULL,
    exploit_code text,
    source text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.exploits OWNER TO pabit_user;

--
-- Name: exploits_id_seq; Type: SEQUENCE; Schema: public; Owner: pabit_user
--

CREATE SEQUENCE public.exploits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exploits_id_seq OWNER TO pabit_user;

--
-- Name: exploits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pabit_user
--

ALTER SEQUENCE public.exploits_id_seq OWNED BY public.exploits.id;


--
-- Name: mitre_attack; Type: TABLE; Schema: public; Owner: pabit_user
--

CREATE TABLE public.mitre_attack (
    id integer NOT NULL,
    tactic_id text NOT NULL,
    tactic_name text NOT NULL,
    tactic_description text NOT NULL,
    technique_id text NOT NULL,
    technique_name text NOT NULL,
    technique_description text
);


ALTER TABLE public.mitre_attack OWNER TO pabit_user;

--
-- Name: mitre_attack_id_seq; Type: SEQUENCE; Schema: public; Owner: pabit_user
--

CREATE SEQUENCE public.mitre_attack_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mitre_attack_id_seq OWNER TO pabit_user;

--
-- Name: mitre_attack_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pabit_user
--

ALTER SEQUENCE public.mitre_attack_id_seq OWNED BY public.mitre_attack.id;


--
-- Name: news_articles; Type: TABLE; Schema: public; Owner: pabit_user
--

CREATE TABLE public.news_articles (
    id integer NOT NULL,
    title text NOT NULL,
    summary text NOT NULL,
    content text,
    source text NOT NULL,
    image_url text,
    link text,
    tags text[] DEFAULT '{}'::text[],
    published_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.news_articles OWNER TO pabit_user;

--
-- Name: news_articles_id_seq; Type: SEQUENCE; Schema: public; Owner: pabit_user
--

CREATE SEQUENCE public.news_articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.news_articles_id_seq OWNER TO pabit_user;

--
-- Name: news_articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pabit_user
--

ALTER SEQUENCE public.news_articles_id_seq OWNED BY public.news_articles.id;


--
-- Name: news_comments; Type: TABLE; Schema: public; Owner: pabit_user
--

CREATE TABLE public.news_comments (
    id integer NOT NULL,
    article_id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.news_comments OWNER TO pabit_user;

--
-- Name: news_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: pabit_user
--

CREATE SEQUENCE public.news_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.news_comments_id_seq OWNER TO pabit_user;

--
-- Name: news_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pabit_user
--

ALTER SEQUENCE public.news_comments_id_seq OWNED BY public.news_comments.id;


--
-- Name: news_likes; Type: TABLE; Schema: public; Owner: pabit_user
--

CREATE TABLE public.news_likes (
    id integer NOT NULL,
    article_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.news_likes OWNER TO pabit_user;

--
-- Name: news_likes_id_seq; Type: SEQUENCE; Schema: public; Owner: pabit_user
--

CREATE SEQUENCE public.news_likes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.news_likes_id_seq OWNER TO pabit_user;

--
-- Name: news_likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pabit_user
--

ALTER SEQUENCE public.news_likes_id_seq OWNED BY public.news_likes.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: pabit_user
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    is_read boolean DEFAULT false,
    related_id integer,
    related_type text,
    from_user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO pabit_user;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: pabit_user
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO pabit_user;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pabit_user
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: post_comments; Type: TABLE; Schema: public; Owner: pabit_user
--

CREATE TABLE public.post_comments (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.post_comments OWNER TO pabit_user;

--
-- Name: post_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: pabit_user
--

CREATE SEQUENCE public.post_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.post_comments_id_seq OWNER TO pabit_user;

--
-- Name: post_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pabit_user
--

ALTER SEQUENCE public.post_comments_id_seq OWNED BY public.post_comments.id;


--
-- Name: post_likes; Type: TABLE; Schema: public; Owner: pabit_user
--

CREATE TABLE public.post_likes (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.post_likes OWNER TO pabit_user;

--
-- Name: post_likes_id_seq; Type: SEQUENCE; Schema: public; Owner: pabit_user
--

CREATE SEQUENCE public.post_likes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.post_likes_id_seq OWNER TO pabit_user;

--
-- Name: post_likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pabit_user
--

ALTER SEQUENCE public.post_likes_id_seq OWNED BY public.post_likes.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: pabit_user
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    tags text[] DEFAULT '{}'::text[],
    attachments text[] DEFAULT '{}'::text[] NOT NULL,
    likes integer DEFAULT 0,
    comments integer DEFAULT 0,
    shares integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.posts OWNER TO pabit_user;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: pabit_user
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.posts_id_seq OWNER TO pabit_user;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pabit_user
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: user_submissions; Type: TABLE; Schema: public; Owner: pabit_user
--

CREATE TABLE public.user_submissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    severity text,
    category text NOT NULL,
    tags text[] DEFAULT '{}'::text[],
    affected_software text,
    versions text,
    cvss_score numeric,
    platform text,
    exploit_type text,
    exploit_code text,
    target_cve text,
    status text DEFAULT 'pending'::text NOT NULL,
    verified boolean DEFAULT false,
    review_notes text,
    reviewed_by integer,
    reviewed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_submissions OWNER TO pabit_user;

--
-- Name: user_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: pabit_user
--

CREATE SEQUENCE public.user_submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_submissions_id_seq OWNER TO pabit_user;

--
-- Name: user_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pabit_user
--

ALTER SEQUENCE public.user_submissions_id_seq OWNED BY public.user_submissions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: pabit_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    job_title text,
    avatar text,
    bio text,
    location text,
    website text,
    reputation integer DEFAULT 0,
    post_count integer DEFAULT 0,
    likes_received integer DEFAULT 0,
    comments_count integer DEFAULT 0,
    cve_submissions integer DEFAULT 0,
    exploit_submissions integer DEFAULT 0,
    verified_submissions integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO pabit_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: pabit_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO pabit_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pabit_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: cve_entries id; Type: DEFAULT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.cve_entries ALTER COLUMN id SET DEFAULT nextval('public.cve_entries_id_seq'::regclass);


--
-- Name: exploits id; Type: DEFAULT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.exploits ALTER COLUMN id SET DEFAULT nextval('public.exploits_id_seq'::regclass);


--
-- Name: mitre_attack id; Type: DEFAULT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.mitre_attack ALTER COLUMN id SET DEFAULT nextval('public.mitre_attack_id_seq'::regclass);


--
-- Name: news_articles id; Type: DEFAULT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.news_articles ALTER COLUMN id SET DEFAULT nextval('public.news_articles_id_seq'::regclass);


--
-- Name: news_comments id; Type: DEFAULT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.news_comments ALTER COLUMN id SET DEFAULT nextval('public.news_comments_id_seq'::regclass);


--
-- Name: news_likes id; Type: DEFAULT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.news_likes ALTER COLUMN id SET DEFAULT nextval('public.news_likes_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: post_comments id; Type: DEFAULT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.post_comments ALTER COLUMN id SET DEFAULT nextval('public.post_comments_id_seq'::regclass);


--
-- Name: post_likes id; Type: DEFAULT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.post_likes ALTER COLUMN id SET DEFAULT nextval('public.post_likes_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: user_submissions id; Type: DEFAULT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.user_submissions ALTER COLUMN id SET DEFAULT nextval('public.user_submissions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: cve_entries; Type: TABLE DATA; Schema: public; Owner: pabit_user
--

COPY public.cve_entries (id, cve_id, title, description, cvss_score, severity, vendor, published_date, updated_date, tags, actively_exploited, edb_id, "references") FROM stdin;
\.


--
-- Data for Name: exploits; Type: TABLE DATA; Schema: public; Owner: pabit_user
--

COPY public.exploits (id, cve_id, exploit_id, title, description, exploit_type, platform, verified, date_published, author, source_url, exploit_code, source, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mitre_attack; Type: TABLE DATA; Schema: public; Owner: pabit_user
--

COPY public.mitre_attack (id, tactic_id, tactic_name, tactic_description, technique_id, technique_name, technique_description) FROM stdin;
\.


--
-- Data for Name: news_articles; Type: TABLE DATA; Schema: public; Owner: pabit_user
--

COPY public.news_articles (id, title, summary, content, source, image_url, link, tags, published_at) FROM stdin;
\.


--
-- Data for Name: news_comments; Type: TABLE DATA; Schema: public; Owner: pabit_user
--

COPY public.news_comments (id, article_id, user_id, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: news_likes; Type: TABLE DATA; Schema: public; Owner: pabit_user
--

COPY public.news_likes (id, article_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: pabit_user
--

COPY public.notifications (id, user_id, type, title, message, is_read, related_id, related_type, from_user_id, created_at) FROM stdin;
\.


--
-- Data for Name: post_comments; Type: TABLE DATA; Schema: public; Owner: pabit_user
--

COPY public.post_comments (id, post_id, user_id, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: post_likes; Type: TABLE DATA; Schema: public; Owner: pabit_user
--

COPY public.post_likes (id, post_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: pabit_user
--

COPY public.posts (id, user_id, content, tags, attachments, likes, comments, shares, created_at) FROM stdin;
\.


--
-- Data for Name: user_submissions; Type: TABLE DATA; Schema: public; Owner: pabit_user
--

COPY public.user_submissions (id, user_id, type, title, description, severity, category, tags, affected_software, versions, cvss_score, platform, exploit_type, exploit_code, target_cve, status, verified, review_notes, reviewed_by, reviewed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: pabit_user
--

COPY public.users (id, username, email, name, password_hash, role, job_title, avatar, bio, location, website, reputation, post_count, likes_received, comments_count, cve_submissions, exploit_submissions, verified_submissions, created_at) FROM stdin;
1	testuser	test@example.com	Test User	scrypt:aabfac5694fb7eae41e0d473a5291533:4e048f1bf7d3fd8e372304a1c32ecff8c3406da380c7b34e60b4851282e85bda	user	\N	\N	\N	\N	\N	0	0	0	0	0	0	0	2025-10-01 12:50:44.11
\.


--
-- Name: cve_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pabit_user
--

SELECT pg_catalog.setval('public.cve_entries_id_seq', 1, false);


--
-- Name: exploits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pabit_user
--

SELECT pg_catalog.setval('public.exploits_id_seq', 1, false);


--
-- Name: mitre_attack_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pabit_user
--

SELECT pg_catalog.setval('public.mitre_attack_id_seq', 1, false);


--
-- Name: news_articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pabit_user
--

SELECT pg_catalog.setval('public.news_articles_id_seq', 1, false);


--
-- Name: news_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pabit_user
--

SELECT pg_catalog.setval('public.news_comments_id_seq', 1, false);


--
-- Name: news_likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pabit_user
--

SELECT pg_catalog.setval('public.news_likes_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pabit_user
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: post_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pabit_user
--

SELECT pg_catalog.setval('public.post_comments_id_seq', 1, false);


--
-- Name: post_likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pabit_user
--

SELECT pg_catalog.setval('public.post_likes_id_seq', 1, false);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pabit_user
--

SELECT pg_catalog.setval('public.posts_id_seq', 1, false);


--
-- Name: user_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pabit_user
--

SELECT pg_catalog.setval('public.user_submissions_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pabit_user
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: cve_entries cve_entries_cve_id_unique; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.cve_entries
    ADD CONSTRAINT cve_entries_cve_id_unique UNIQUE (cve_id);


--
-- Name: cve_entries cve_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.cve_entries
    ADD CONSTRAINT cve_entries_pkey PRIMARY KEY (id);


--
-- Name: exploits exploits_pkey; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.exploits
    ADD CONSTRAINT exploits_pkey PRIMARY KEY (id);


--
-- Name: mitre_attack mitre_attack_pkey; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.mitre_attack
    ADD CONSTRAINT mitre_attack_pkey PRIMARY KEY (id);


--
-- Name: news_articles news_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.news_articles
    ADD CONSTRAINT news_articles_pkey PRIMARY KEY (id);


--
-- Name: news_comments news_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.news_comments
    ADD CONSTRAINT news_comments_pkey PRIMARY KEY (id);


--
-- Name: news_likes news_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.news_likes
    ADD CONSTRAINT news_likes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: post_comments post_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_pkey PRIMARY KEY (id);


--
-- Name: post_likes post_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: user_submissions user_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.user_submissions
    ADD CONSTRAINT user_submissions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: news_comments news_comments_article_id_news_articles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.news_comments
    ADD CONSTRAINT news_comments_article_id_news_articles_id_fk FOREIGN KEY (article_id) REFERENCES public.news_articles(id) ON DELETE CASCADE;


--
-- Name: news_comments news_comments_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.news_comments
    ADD CONSTRAINT news_comments_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: news_likes news_likes_article_id_news_articles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.news_likes
    ADD CONSTRAINT news_likes_article_id_news_articles_id_fk FOREIGN KEY (article_id) REFERENCES public.news_articles(id) ON DELETE CASCADE;


--
-- Name: news_likes news_likes_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.news_likes
    ADD CONSTRAINT news_likes_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_from_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_from_user_id_users_id_fk FOREIGN KEY (from_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: post_comments post_comments_post_id_posts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_post_id_posts_id_fk FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_comments post_comments_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: post_likes post_likes_post_id_posts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_posts_id_fk FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_likes post_likes_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_submissions user_submissions_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.user_submissions
    ADD CONSTRAINT user_submissions_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: user_submissions user_submissions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pabit_user
--

ALTER TABLE ONLY public.user_submissions
    ADD CONSTRAINT user_submissions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict iMKWlOd5aaoDxHZSjfQpKfPmjEE033hfUcaj4kbVqGJdg9vlH5WD9a2oycqiu3T

